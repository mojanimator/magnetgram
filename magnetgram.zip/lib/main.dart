import 'package:flutter/material.dart';
import 'package:magnetgram/ui/myapp.dart';

void main() => runApp(MaterialApp(
      home: MyApp(),
      debugShowCheckedModeBanner: false,
    ));
