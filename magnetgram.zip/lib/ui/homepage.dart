import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_advanced_networkimage/provider.dart';
import 'package:magnetgram/helper/DivarBloc.dart';
import 'package:magnetgram/helper/helper.dart';
import 'package:magnetgram/helper/lang.dart';
import 'package:magnetgram/helper/variables.dart';
import 'package:magnetgram/model/divar.dart';
import 'package:magnetgram/ui/divardetails.dart';

class HomePage extends StatefulWidget {
  final BuildContext appContext;

  HomePage(this.appContext);

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with WidgetsBindingObserver {
  Future<List<Divar>> divars;
  DivarBloc _bloc;

  _HomePageState();

  @override
  void initState() {
    print("init");
    WidgetsBinding.instance.addObserver(this);
    super.initState();
    SchedulerBinding.instance.addPostFrameCallback((_) => refreshData());
  }

  @override
  void dispose() {
    print("dispose");
    super.dispose();
    // this.bloc.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    print(state);
    if (state == AppLifecycleState.resumed) {
      //do your stuff
    }
  }

  @override
  Widget build(BuildContext appContext) {
    _bloc ??= DivarBloc();
    return StreamBuilder<List<Divar>>(
        stream: _bloc.stream,
        builder: (BuildContext appContext, AsyncSnapshot snapshot) {
//          print(bloc.stream);
          print(snapshot.connectionState);
          switch (snapshot.connectionState) {
            case ConnectionState.none:
              return new Text(Lang.get[Variable.LANG][Lang.CHECK_NETWORK]);
            case ConnectionState.waiting:
              return new Center(child: CircularProgressIndicator());
            case ConnectionState.done:
              return new Text(Lang.get[Variable.LANG][Lang.CHECK_NETWORK]);
            case ConnectionState.active:
              if (snapshot.hasError) {
                return new Text(
                  Lang.get[Variable.LANG][Lang.CHECK_NETWORK],
                  //  '${snapshot.error}',
                  style: TextStyle(fontSize: 24.0, color: Colors.black),
                );
              }
              if (snapshot.data == null) {
                return Container(child: Center(child: Text("Loading...")));
              } else {
//                print(snapshot.data);
                return ListView.builder(
                  itemCount: snapshot.data.length,
                  itemBuilder: (BuildContext context, int index) {
                    return _row(appContext, snapshot.data[index]);
                  },
                );
              }
              break;
            default:
              return null;
          }
        });
  }

  Widget _row(BuildContext appContext, Divar divar) {
    print(Helper.getImageLink(divar.chat_id));
    return ListTile(
      leading: CircleAvatar(
        backgroundImage: AdvancedNetworkImage(
            Helper.getImageLink(divar.chat_id),
            fallbackAssetImage: "images/no-image.jpg"),
      ),
      title: Text(divar.chat_title),
      subtitle: Text(divar.chat_description),
      onTap: () {
        Navigator.push(
            appContext,
            MaterialPageRoute(
                maintainState: true,
                builder: (context) {
                  return DivarDetails(divar);
                }));
        //        refreshData();
      },
    );
  }

  void refreshData() async {
//    print("refresh data");
    _bloc.sink.add(await Helper.getDivar(context, null));
  }
}
