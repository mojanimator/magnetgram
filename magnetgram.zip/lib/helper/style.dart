import 'package:flutter/material.dart';

class Styles {
  static TextStyle TEXTSTYLE = TextStyle(fontFamily: 'Tanha', fontSize: 20.0);
}
