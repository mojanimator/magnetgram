import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:connectivity/connectivity.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:magnetgram/helper/lang.dart';
import 'package:magnetgram/helper/variables.dart';
import 'package:magnetgram/model/divar.dart';
import 'package:magnetgram/ui/loginpage.dart';
import 'package:magnetgram/ui/myapp.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Helper {
  static var client = http.Client();
  static SharedPreferences localStorage;
  static int showAdTimes = 0;
  static Directory directory;
  static Map<String, dynamic> appIds;
  static String accessToken;

//  static MobileAdTargetingInfo targetingInfo;
//  static BannerAd bannerAd;

  static void prepare(BuildContext context) async {
    directory = await getExternalStorageDirectory();
    localStorage = await getLocalStorage();
    appIds = await loadAppIds(context);
  }

  static Future<SharedPreferences> getLocalStorage() async {
    localStorage = await SharedPreferences.getInstance();
    accessToken = localStorage.getString('access_token');
    localStorage.setInt('last_seen', DateTime.now().millisecondsSinceEpoch);
//    refreshToken = localStorage.getString('refresh_token');
//    username = localStorage.getString('username');
//    name = localStorage.getString('name');
//    family = localStorage.getString('family');
//    phoneNumber = localStorage.getString('phone_number');
//    fashionImages = localStorage.getInt('fashion_images');
    return localStorage;
  }

  static Future<bool> isNetworkConnected() async {
//    print("isNetworkConnected");
    var connectivityResult = await (Connectivity().checkConnectivity());

    Connectivity().onConnectivityChanged.listen((ConnectivityResult result) {
      if (result == ConnectivityResult.none) {
      } else if (result == ConnectivityResult.wifi ||
          result == ConnectivityResult.mobile) {
//        initAdmob();
      }
    });
    return connectivityResult == ConnectivityResult.mobile ||
        connectivityResult == ConnectivityResult.wifi;
  }

  static login(context, username, password) {
    return client.post(Variable.LOGIN, headers: {
      'Accept': 'application/json',
      // 'Authorization': 'Bearer ' + accessToken
    }, body: {
      'username': username,
      'password': password,
    }).then((http.Response response) {
      var parsedJson = json.decode(response.body);
      if (parsedJson['access_token'] != null) {
        localStorage.setString('access_token', parsedJson['access_token']);
        print(parsedJson['access_token']);
      }
      if (parsedJson['refresh_token'] != null) {
        localStorage.setString('refresh_token', parsedJson['refresh_token']);
      }
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => MyApp()),
      );
    }).catchError((e) {
      print(json.decode(e.message));
      print(e);
      showMessage(context, json.decode(e.message));
    });
  }

  static logout(context) {
    return client.post(Variable.LOGOUT, headers: {
      'Accept': 'application/json',
      'Authorization': 'Bearer ' + accessToken
    }, body: {}).then((http.Response response) {
      // print(response.body);

      var parsedJson = json.decode(response.body);
      print('logout');
      print(response.body);
      //status 400=user not found
      //status 200=successfull logout
      if (parsedJson['status'] != null &&
              (parsedJson['status'] == 200 || parsedJson['status'] == 400) ||
          (parsedJson['message'] != null &&
              parsedJson['message'].contains('Unauthenticated'))) {
        localStorage.setString('access_token', null);
        localStorage.setString('refresh_token', null);
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => LoginPage()),
        );
      } else {
        showMessage(context, 'خطایی رخ داد  ');
      }
    }).catchError((e) {
      showMessage(context, json.decode(e.message));
      print(json.decode(e.message));
      print(e);
    });
  }

  static Future<String> checkAndSetUpdates() async {
    try {
      // if (accessToken != '')
      if (localStorage == null) await getLocalStorage();
      int lastSeen = localStorage.getInt('last_seen') ?? 0;
      return client.get(
        Variable.CHECK_UPDATE,
        headers: {"Content-Type": "application/json"},
      ).then((http.Response response) async {
        String updateMessage = response.body;
//        print(localFashionImages.toString() + "," + fashionImages.toString());
        if (updateMessage != null) {
          return updateMessage; //first time that app starts not show notification
        }
        return null;
      }, onError: (e) {
        return null;
      });
    } catch (e) {
//      showMessage(context, e.toString());
      print("error in my helper  $e.toString()");
      return null;
//      throw Exception(e.toString());
    }
  }

  static Future<List<Divar>> getDivar(context, params) async {
    if (accessToken != '')
      try {
        Uri uri = Uri.parse(Variable.LINK_DIVAR);
        final newURI =
            params != null ? uri.replace(queryParameters: params) : uri;
//        print(accessToken);
        if (accessToken != '')
          return client.get(
            newURI,
            headers: {
              'Accept': 'application/json',
              'Authorization': 'Bearer ' + accessToken
            },
          ).then((http.Response response) async {
            List<Divar> divars = List<Divar>();

            if (response.statusCode != 200) return null;
            var parsedJson = json.decode(response.body);

            for (final tmp in parsedJson) {
              Divar d = Divar.fromJson(tmp);
              divars.add(d);
            }

            return divars;
          }, onError: (e) {
            showMessage(context, Lang.get[Variable.LANG][Lang.CHECK_NETWORK]);
            print("onError");
            return null;
          });
      } catch (e) {
        print("catch");
        showMessage(context, Lang.get[Variable.LANG][Lang.CHECK_NETWORK]);
        return null;
      }
    else {
      //token not found ,move to login page
      logout(context);
      print('null');
      return (null);
    }
  }

  static Future<void> saveWallpaper(
      BuildContext context, Uint8List bytes, String path) async {
    try {
      final myImagePath = '${directory.path}/Fashion_Wallpapers';

      if (!File("$myImagePath/$path").existsSync()) {
        if (!Directory(myImagePath).existsSync())
          await new Directory(myImagePath).create();
//        var request = await HttpClient()
//            .getUrl(Uri.parse(Variable.STORAGE + "/" + group_id + "/" + path));
//        var response = await request.close();
//        Uint8List bytes = await consolidateHttpClientResponseBytes(response);
/*var file = */
        new File("$myImagePath/$path")..writeAsBytesSync(bytes);
      }
      showMessage(
          context, "  Wallpaper Saved To $myImagePath/$path Successfully !");
    } on PlatformException catch (e) {
      Navigator.pop(context);
    } catch (e) {
//      print('error: $e');
    }
  }

  static void showMessage(context, message) {
    if (context == null) return;
    final snackBar = SnackBar(
      content: Text(message),
      action: SnackBarAction(
        label: 'X',
        textColor: Colors.yellow,
        onPressed: () {
          Scaffold.of(context).hideCurrentSnackBar();
        },
      ),
    );
    Scaffold.of(context)
      ..removeCurrentSnackBar()
      ..showSnackBar(snackBar);
  }

//  static BannerAd createBannerAd() {
//    return BannerAd(
//      adUnitId: appIds["BANNER_UNIT_TEST"].toString(),
//      size: AdSize.fullBanner,
//      targetingInfo: targetingInfo,
//      listener: (MobileAdEvent event) {
////        print("BannerAd event $event");
//      },
//    );
//  }

//  static InterstitialAd createInterstitialAd() {
//    return InterstitialAd(
//      adUnitId: appIds["INTERSTITIAL_UNIT_TEST"].toString(),
//      targetingInfo: targetingInfo,
//      listener: (MobileAdEvent event) {
////        print("InterstitialAd event $event");
//      },
//    );
//  }

//  static void initAdmob() async {
//    FirebaseAdMob.instance
//        .initialize(appId: appIds["APP_ID"].toString())
//        .then((onValue) {
//      targetingInfo = MobileAdTargetingInfo(
//        keywords: <String>['telegram', 'follower', 'instagram'],
////        contentUrl: 'https://flutter.io',
////    birthday: DateTime.now(),
////        childDirected: false,
////    designedForFamilies: false,
////    gender: MobileAdGender.unknown,
//        // or MobileAdGender.female, MobileAdGender.unknown
//        // Android emulators are considered test devices
//        testDevices: <String>[],
//      );
//
//      RewardedVideoAd.instance.load(
//          adUnitId: appIds["REWARDED_UNIT_TEST"].toString(),
//          targetingInfo: targetingInfo);
//
//      bannerAd = createBannerAd();
//      bannerAd
//        ..load()
//        ..show(
//          anchorOffset: 0.0,
//          horizontalCenterOffset: 0.0,
//          anchorType: AnchorType.bottom,
//        );
//    });
//  }

//  static void loadRewardedVideo() {
//    RewardedVideoAd.instance
//        .load(
//            adUnitId: appIds["REWARDED_UNIT_TEST"].toString(),
//            targetingInfo: targetingInfo)
//        .then((onValue) {});
//  }

//  static void showRewardedVideo() {
//    RewardedVideoAd.instance.show().then((onValue) {}, onError: (e) {
//      loadRewardedVideo();
//    });
//  }

  static Future<Map<String, dynamic>> loadAppIds(BuildContext context) async {
    String data = await DefaultAssetBundle.of(context).loadString("ids.json");
    return json.decode(data);
  }

  static String getImageLink(String chat_id) {
    return Variable.LINK_IMAGES + "/$chat_id.jpg";
  }
}
