class Variable {
  static String LANG = "fa";
  static String DOMAIN = "https://vartashop.ir/magnetgram/"

      /*"http://10.0.3.2:8000/"*/;

  static String APIDOMAIN = /*"http://moj-raj.ir/"*/ "${DOMAIN}api/";

  static String LINK_DIVAR = "${APIDOMAIN}getdivar";
  static String LINK_IMAGES = "${DOMAIN}storage";
  static String LINK_REFRESH = "${APIDOMAIN}refreshinfo";
  static String CHECK_UPDATE = "${APIDOMAIN}checkupdate";

  static String LOGIN = "${APIDOMAIN}login";
  static String LOGOUT = "${APIDOMAIN}logout";

  static String COMMAND_REFRESH_DIVAR = "REFRESH_DIVAR";

  static Map<String, String> ERROR = {
    "DISCONNECTED": "اتصال برقرار نیست",
  };
}

enum Commands { RefreshWallpapers }
