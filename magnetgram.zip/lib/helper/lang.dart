class Lang {
  static int HELLO = 1;
  static int CHECK_NETWORK = 2;
  static int APP_NAME = 3;
  static int TELEGRAM_USERNAME_HINT = 4;
  static int PASSWORD_HINT = 5;
  static Map<String, Map<int, String>> get = {
    "fa": {
      HELLO: "سلام",
      CHECK_NETWORK: "اتصال اینترنت خود را بررسی کرده و مجدد تلاش کنید.",
      APP_NAME: "مگنت گرام",
      TELEGRAM_USERNAME_HINT: "نام کاربری تلگرام (@...)",
      PASSWORD_HINT: "رمز عبور",
    },
    "en": {
      HELLO: "Hello",
      CHECK_NETWORK: "Check Your Internet Connection And Try Again.",
      APP_NAME: "Magnet Gram",
      TELEGRAM_USERNAME_HINT: "Your Telegram Username (@...)",
      PASSWORD_HINT: "Password",
    }
  };
}
